<?php
define('DBSERVER','localhost');
define('DBUSERNAME','covisafeDBA');
define('DBPASSWORD','covisafe123');
define('DBNAME','Covisafe');

$db=mysqli_connect(DBSERVER,DBUSERNAME,DBPASSWORD,DBNAME);

if($db)
{
    echo "Connection Established";
}
else
die("Error: connection error" .mysqli_connect_error());

?>